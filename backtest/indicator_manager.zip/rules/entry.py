# rules/entry.py
from typing import Any, Dict, Tuple
def rsi_overbought(self: Any, ctx: Dict[str, Any]) -> Tuple[bool, str]:
    return self._entry_allows(ctx['rsi_val']), ""
ENTRY_RULES = {"RSIOverbought": rsi_overbought}
