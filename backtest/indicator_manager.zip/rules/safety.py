# rules/safety.py
from datetime import timedelta
from typing import Any, Dict, Tuple

def rsi_under_dynamic_threshold(self: Any, ctx: Dict[str, Any]) -> Tuple[bool, str]:
    return self._safety_allows(ctx['rsi_val'], ctx['dynamic_thr'], ctx['level']), ""

def cooldown_between_sos(self: Any, ctx: Dict[str, Any]) -> Tuple[bool, str]:
    mins = getattr(self, "so_cooldown_minutes", 0) or 0
    if mins <= 0:
        return True, ""
    now = ctx["current_time"]
    level = ctx["level"]
    last = self.last_safety_order_time or self.base_order_time
    if last is None:
        return True, ""
    if now - last >= timedelta(minutes=mins):
        return True, ""
    if self.debug_trade:
        self.logger.debug(f"Skip DCA-{level}: cooldown {(now - last)} < {mins}m")
    return False, "Cooldown not elapsed"

SAFETY_RULES = {
    "RSIUnderDynamicThreshold": rsi_under_dynamic_threshold,
    "CooldownBetweenSOs": cooldown_between_sos,
}
