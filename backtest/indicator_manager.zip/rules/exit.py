
# rules/exit.py
from typing import Any, Dict, Tuple
def tp_decay_reached(self: Any, ctx: Dict[str, Any]) -> Tuple[bool, str]:
    return self._exit_allows(ctx['current_time']), ""
EXIT_RULES = {"TPDecayReached": tp_decay_reached}
